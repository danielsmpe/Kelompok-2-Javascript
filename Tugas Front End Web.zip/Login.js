const loginForm = document.getElementById("login-form");
const loginButton = document.getElementById("login-form-submit");

loginButton.addEventListener("click", (e) => {
    e.preventDefault();
    const username = loginForm.username.value;
    const password = loginForm.password.value;

    if (username === "Daniel" && password === "sampe") {
        document.location = "Home.html";
    }
    else if (username === "julian" && password === "Maringka") {
        document.location = "home.html";
    }
    else if (username === "Novaldy" && password === "Pandesia") {
        document.location = "Home.html";
    }
    else if (username === "Insherne" && password === "ronsumbre") {
        document.location = "Home.html";
    }else {
        swal(title = "username or password is incorrect.");

    }
})